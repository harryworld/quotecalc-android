(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zenorocha:clipboard'] = {};

})();

//# sourceMappingURL=zenorocha_clipboard.js.map
