(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// packages/reywood_iron-router-ga/lib/browser_policy.js                 //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
Meteor.startup(function() {                                              // 1
    if (typeof BrowserPolicy === 'undefined') { return; }                // 2
                                                                         // 3
    BrowserPolicy.content.allowImageOrigin('www.google-analytics.com');  // 4
    BrowserPolicy.content.allowScriptOrigin('www.google-analytics.com');
});                                                                      // 6
                                                                         // 7
///////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reywood:iron-router-ga'] = {};

})();

//# sourceMappingURL=reywood_iron-router-ga.js.map
