(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.coffee.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('choices', function(params) {                           // 1
  return Choices.find(params);                                         //
});                                                                    // 1
                                                                       //
Meteor.publish('contacts', function() {                                // 1
  return Contacts.find();                                              //
});                                                                    // 4
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.coffee.js.map
