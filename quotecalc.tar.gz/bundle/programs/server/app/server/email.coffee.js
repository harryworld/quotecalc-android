(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/email.coffee.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  sendEmail: function(to, from, subject, text) {                       // 2
    check([to, from, subject, text], [String]);                        // 3
    this.unblock();                                                    // 3
    return Email.send({                                                //
      to: to,                                                          // 8
      from: from,                                                      // 8
      subject: subject,                                                // 8
      text: text                                                       // 8
    });                                                                //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=email.coffee.js.map
